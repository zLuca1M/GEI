
# Gestão de Estoque Inteligente

## Descrição
O **Gestão de Estoque Inteligente** é um sistema desenvolvido para pequenas e médias empresas (PMEs) que desejam gerenciar seus estoques de forma eficiente. Este projeto inclui funcionalidades para cadastro de produtos, controle de movimentações de entrada e saída, geração de relatórios e integração com fornecedores.

## Tecnologias Utilizadas
- **Linguagem Backend:** Python (Django)
- **Frontend:** HTML, CSS e JavaScript (React.js)
- **Banco de Dados:** PostgreSQL
- **Hospedagem:** Amazon Web Services (AWS)

## Funcionalidades
- Cadastro e gerenciamento de produtos e fornecedores.
- Registro de movimentações de entrada e saída de produtos.
- Geração de relatórios analíticos.
- Responsividade para dispositivos móveis e desktops.

## Estrutura do Projeto
- **/database.sql:** Contém o script SQL para criação das tabelas do banco de dados.
- **/backend:** Código do backend utilizando Django (caso inclua).
- **/frontend:** Código do frontend utilizando React.js (caso inclua).

## Como Configurar
1. Clone o repositório:
   ```bash
   git clone https://github.com/seu-usuario/Gestao_Estoque_Inteligente.git
   cd Gestao_Estoque_Inteligente
   ```
2. Configure o banco de dados utilizando o script SQL no arquivo `database.sql`.
3. (Opcional) Configure o ambiente do backend e frontend.

## Estrutura do Banco de Dados
- **Fornecedor:** Tabela para armazenar informações dos fornecedores.
- **Produto:** Tabela para cadastro de produtos vinculados a fornecedores.
- **Movimentação:** Tabela para registrar entradas e saídas de produtos.

## Contribuições
Contribuições são bem-vindas! Para contribuir:
1. Faça um fork do projeto.
2. Crie uma nova branch:
   ```bash
   git checkout -b minha-feature
   ```
3. Submeta suas alterações:
   ```bash
   git commit -m "Descrição da alteração"
   git push origin minha-feature
   ```
4. Abra um Pull Request.
